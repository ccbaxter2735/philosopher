/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_fct2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: terussar <terussar@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/24 14:50:34 by terussar          #+#    #+#             */
/*   Updated: 2023/08/24 15:20:40 by terussar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosopher.h"

void	define_fork(t_philo *philo)
{
	philo->tab_fork[0] = (philo->id 
	+ (philo->id % 2)) % philo->r_philo->nb_philo;
  philo->tab_fork[1] = (philo->id
	+ !(philo->id % 2)) % philo->r_philo->nb_philo;
}

void	ft_usleep(t_philo *philo, long time)
{
	long	time2;

	if (is_dead(philo) != 0)
		exit(1);
	time2 = ft_time();
	while ((ft_time() - time2) < time)
	{
		if (is_dead(philo) != 0)
			exit(1);
		usleep(50);
	}
}