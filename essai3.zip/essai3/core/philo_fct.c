/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_fct.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: terussar <terussar@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/24 14:50:52 by terussar          #+#    #+#             */
/*   Updated: 2023/08/24 15:18:54 by terussar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosopher.h"

long	ft_time()
{
	struct	timeval	current_time;
	long			time_ms;

	if(gettimeofday (&current_time, NULL) == -1)
	{
		ft_strerror("error\ngettimeofday returned -1\n");
		return (-1);
	}
	time_ms = (current_time.tv_usec / 1000) + (current_time.tv_sec * 1000);
	return (time_ms);
}

void	take_time_and_str(t_philo *philo, char *str)
{
	long	time;

	time = -1;
	time = ft_time() - philo->start_time;
	if (time > 0)
		printf("%ld %d %s\n", time, philo->id, str);
}

int	ft_eat(t_philo *philo1)
{
	if (is_dead(philo1) == 0)
	{
		pthread_mutex_lock(&philo1->data->mutex_id[philo1->tab_fork[0]]);
		pthread_mutex_lock(&philo1->r_philo->write);
		take_time_and_str(philo1, "has take a fork");
		pthread_mutex_unlock(&philo1->r_philo->write);

		pthread_mutex_lock(&philo1->data->mutex_id[philo1->tab_fork[1]]);
		pthread_mutex_lock(&philo1->r_philo->write);
		take_time_and_str(philo1, "has take a fork");
		pthread_mutex_unlock(&philo1->r_philo->write);

		pthread_mutex_lock(&philo1->r_philo->write);
		take_time_and_str(philo1, "is eating");
		pthread_mutex_unlock(&philo1->r_philo->write);

		ft_usleep(philo1, philo1->r_philo->time_to_eat);
		pthread_mutex_unlock(&philo1->data->mutex_id[philo1->tab_fork[0]]);
		pthread_mutex_unlock(&philo1->data->mutex_id[philo1->tab_fork[1]]);
		philo1->last_time_eat = ft_time();
		if (philo1->nb_meal != -1)
			philo1->nb_meal--;
		return (0);
	}
	return (1);
}

int	ft_sleep(t_philo *philo1)
{
	if (is_dead(philo1) == 0)
	{
		pthread_mutex_lock(&philo1->r_philo->write);
		take_time_and_str(philo1, "is sleeping");
		pthread_mutex_unlock(&philo1->r_philo->write);
		ft_usleep(philo1, philo1->r_philo->time_to_sleep);
		return (0);
	}
	return (1);
}

int	ft_think(t_philo *philo1)
{
	if (is_dead(philo1) == 0)
	{
		pthread_mutex_lock(&philo1->r_philo->write);
		take_time_and_str(philo1, "is thinking");
		pthread_mutex_unlock(&philo1->r_philo->write);
		return (0);
	}
	return (1);
}